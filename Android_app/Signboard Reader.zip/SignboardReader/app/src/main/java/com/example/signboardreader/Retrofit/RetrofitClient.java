package com.example.signboardreader.Retrofit;

import java.util.concurrent.TimeUnit;

import retrofit2.Retrofit;
import okhttp3.OkHttpClient;
import retrofit2.converter.scalars.ScalarsConverterFactory;

public class RetrofitClient {
    private static Retrofit retrofitClient = null;

    public static Retrofit getClient()
    {
        if(retrofitClient == null)
        {
            OkHttpClient okHttpClient = new OkHttpClient.Builder()
                    .connectTimeout(10, TimeUnit.MINUTES)
                    .readTimeout(3000, TimeUnit.SECONDS)
                    .writeTimeout(15, TimeUnit.SECONDS)
                    .build();
            retrofitClient = new Retrofit.Builder()
                    .baseUrl("http://10.0.2.2:5000")
                    .client(okHttpClient)
                    .addConverterFactory(ScalarsConverterFactory.create())
                    .build();
        }

        return retrofitClient;
    }
}
