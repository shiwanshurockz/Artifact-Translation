package com.example.signboardreader.Utils;

public interface IUploadCallbacks {
    void  onProgressUpdate (int percent);
}
